# fullstackreact
- A fullstack react application
